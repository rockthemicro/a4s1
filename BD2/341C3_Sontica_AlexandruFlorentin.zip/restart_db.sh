#!/bin/bash

docker stop oracledb
docker start oracledb
