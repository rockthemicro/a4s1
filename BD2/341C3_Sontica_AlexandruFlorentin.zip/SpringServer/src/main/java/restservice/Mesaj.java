package restservice;


public class Mesaj {
    public String text;
}