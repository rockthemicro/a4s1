package databaseObjects;

public class Produs {
    public Integer id;
    public String nume;
    public String description;
    public Integer pret;
    public String url_poza_profil;
    public Integer cantitate;
    public Integer id_categorie;
}
