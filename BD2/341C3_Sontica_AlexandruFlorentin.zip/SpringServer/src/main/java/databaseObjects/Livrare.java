package databaseObjects;

public class Livrare {
    public Integer id;
    public Integer id_curier;
    public Integer id_localitate;
    public Integer taxa;
}
