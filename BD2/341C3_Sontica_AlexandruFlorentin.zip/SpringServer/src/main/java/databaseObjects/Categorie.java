package databaseObjects;

public class Categorie {
    public Integer id;
    public String nume;
}
