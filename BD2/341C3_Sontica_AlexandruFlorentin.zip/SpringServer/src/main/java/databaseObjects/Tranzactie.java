package databaseObjects;

public class Tranzactie {
    public Integer id;
    public Integer id_curier;
    public Integer id_localitate;
    public Integer id_produs;
    public String client_nume;
    public String client_prenume;
    public String client_telefon;
    public String adresa_livrare;
}
