package databaseObjects;

public class Localitate {
    public Integer id;
    public String nume;
}
