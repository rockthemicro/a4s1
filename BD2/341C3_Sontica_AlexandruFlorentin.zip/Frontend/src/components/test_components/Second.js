import React, { Component } from 'react';

class Second extends Component {

    render() {
        return (
            <div>
                <h1>
                    Esti pe second
                </h1>
            </div>
        )
    }

}

export default Second;