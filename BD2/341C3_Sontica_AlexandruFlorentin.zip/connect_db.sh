docker exec -ti oracledb sqlplus system/caca@//localhost:1521/XE
