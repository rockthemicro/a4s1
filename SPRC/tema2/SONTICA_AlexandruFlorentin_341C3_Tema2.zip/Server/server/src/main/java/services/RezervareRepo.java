package services;

import org.springframework.data.repository.CrudRepository;

public interface RezervareRepo extends CrudRepository<Rezervare, Integer> {
}
