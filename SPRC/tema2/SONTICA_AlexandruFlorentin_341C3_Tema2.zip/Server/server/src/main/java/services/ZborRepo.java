package services;

import org.springframework.data.repository.CrudRepository;

public interface ZborRepo extends CrudRepository<Zbor, Integer> {

}
